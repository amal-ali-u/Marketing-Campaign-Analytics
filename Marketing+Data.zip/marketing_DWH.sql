create database marketing_DWH;

--create dimensionTables
create table Dim_Customer(
CustomerKey int identity(1,1) primary key,
CustomerID int NOT NULL ,
Age int,
constraint c1 check( Age>=0),
Income float NOT NULL DEFAULT 0,
Kidhome int NOT NULL DEFAULT 0 ,
Marital_Status nvarchar(255),
Education nvarchar(255),
country nvarchar(255),
Customer_Type nvarchar(255),
Teenhome int NOT NULL DEFAULT 0
)
drop table Dim_Customer
create table Dim_Products(
pro_SK int identity(1,1) primary key,
productName nvarchar(255)
)
drop table Dim_Products

create table Dim_Campaing(
camp_SK  int identity(1,1) primary key,
CampaingName nvarchar(255)
)
drop table Dim_Campaing
create table Dim_Channel(
chan_SK int identity(1,1) primary key,
ChannelName nvarchar(255))

create  table Dim_Date(
DateKey int primary key,
FullDate datetime,
Day NVARCHAR(255),
Month NVARCHAR(255),
Year int
)
drop table Dim_Date

create table Fact_MarketingResult(
Fact_SK int identity(1,1) primary key,
Customer_FK int NOT NULL ,
Enr_DateKey  int NOT NULL,
campaing_FK  int NOT NULL,
Accepted int NOT NULL DEFAULT 0)


create table Fact_CustomerBehavior(
Fact_SK int identity(1,1) primary key,
LastPur_DateKey int not null,
Customer_FK int NOT NULL ,
product_FK int NOT NULL,
channel_FK int NOT NULL,
NumDealsPurchases int NOT NULL DEFAULT 0,
NumWebVisitsMonth int NOT NULL DEFAULT 0,
Response int NOT NULL DEFAULT 0,
Complain int NOT NULL DEFAULT 0,
Spend_Amount float NOT NULL DEFAULT 0,
NumPurachases int NOT NULL DEFAULT 0,
Target NVARCHAR(255) NOT NULL


)
drop table Fact_CustomerBehavior